﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim studentMarks(,) As Integer = {
            {75, 80, 90, 85},
            {80, 85, 95, 90},
            {90, 95, 81, 80},
            {85, 90, 80, 75}
        }

        DataGridView1.ColumnCount = 4
        DataGridView1.RowCount = 4
        DataGridView1.Columns(0).HeaderText = "Mark1"
        DataGridView1.Columns(1).HeaderText = "Mark2"
        DataGridView1.Columns(2).HeaderText = "Mark3"
        DataGridView1.Columns(3).HeaderText = "Mark4"

        For i As Integer = 0 To 3
            For j As Integer = 0 To 3
                DataGridView1.Rows(i).Cells(j).Value = studentMarks(i, j)
            Next
        Next
    End Sub

    Private Sub btnreturn81_Click(sender As Object, e As EventArgs) Handles btnreturn81.Click
        Dim studentMarks(,) As Integer = {
            {75, 80, 90, 85},
            {80, 85, 95, 90},
            {90, 95, 81, 80},
            {85, 90, 80, 75}
        }

        ' Assignment Answer - returns 81
        Dim mark81 As Integer = studentMarks(2, 2)
        txtresults.Text = mark81.ToString()
        DataGridView1.Rows(2).Cells(2).Selected = True
        MessageBox.Show("The 81 marks is at studentMarks(2,2) = " & mark81)
    End Sub

End Class