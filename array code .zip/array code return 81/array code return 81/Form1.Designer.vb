﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.lblselectedmarks = New System.Windows.Forms.Label()
        Me.txtresults = New System.Windows.Forms.TextBox()
        Me.btnreturn81 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(15, 28)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(411, 334)
        Me.DataGridView1.TabIndex = 0
        '
        'lblselectedmarks
        '
        Me.lblselectedmarks.AutoSize = True
        Me.lblselectedmarks.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblselectedmarks.Location = New System.Drawing.Point(12, 391)
        Me.lblselectedmarks.Name = "lblselectedmarks"
        Me.lblselectedmarks.Size = New System.Drawing.Size(201, 31)
        Me.lblselectedmarks.TabIndex = 1
        Me.lblselectedmarks.Text = "Selected Marks"
        '
        'txtresults
        '
        Me.txtresults.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtresults.Location = New System.Drawing.Point(219, 384)
        Me.txtresults.Name = "txtresults"
        Me.txtresults.Size = New System.Drawing.Size(77, 38)
        Me.txtresults.TabIndex = 2
        '
        'btnreturn81
        '
        Me.btnreturn81.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreturn81.Location = New System.Drawing.Point(317, 378)
        Me.btnreturn81.Name = "btnreturn81"
        Me.btnreturn81.Size = New System.Drawing.Size(174, 49)
        Me.btnreturn81.TabIndex = 3
        Me.btnreturn81.Text = "Get Mark 81"
        Me.btnreturn81.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnreturn81)
        Me.Controls.Add(Me.txtresults)
        Me.Controls.Add(Me.lblselectedmarks)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents lblselectedmarks As Label
    Friend WithEvents txtresults As TextBox
    Friend WithEvents btnreturn81 As Button
End Class
